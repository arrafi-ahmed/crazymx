<script setup>
import DefaultBar from './AppBar.vue'
import DefaultView from './View.vue'
import DefaultFooter from './Footer.vue'
</script>

<template>
  <v-app>
    <default-bar />
    <default-view />
    <default-footer />
  </v-app>
</template>
