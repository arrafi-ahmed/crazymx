<script setup></script>
<template>
  <!--  <v-main class="bg-tertiary">-->
  <v-main>
    <div class="fill-height limit-max-width-xl mx-auto">
      <router-view />
    </div>
  </v-main>
</template>
<style></style>
