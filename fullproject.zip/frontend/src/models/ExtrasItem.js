export default class ExtrasItem {
  constructor({ name = null, quantity = 0 } = {}) {
    this.name = name
    this.quantity = quantity
  }
}
